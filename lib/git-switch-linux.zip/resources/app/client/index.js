import React from 'react'
import ReactDOM from 'react-dom'

import Menu from './menu'

ReactDOM.render(
  <Menu />,
  document.getElementById('app-root')
)
